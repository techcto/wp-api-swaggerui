<?php return array('dependencies' => array(), 'version' => '2daef96cd873e50dce30');
