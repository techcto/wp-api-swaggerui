<?php return array('dependencies' => array(), 'version' => '242f1fef933f9b41d741');
