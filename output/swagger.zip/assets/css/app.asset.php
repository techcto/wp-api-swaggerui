<?php return array('dependencies' => array(), 'version' => 'd6bb52903ea293fd9070');
