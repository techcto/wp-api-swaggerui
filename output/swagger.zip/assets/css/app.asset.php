<?php return array('dependencies' => array(), 'version' => '673d4e8d95c49da9d986');
